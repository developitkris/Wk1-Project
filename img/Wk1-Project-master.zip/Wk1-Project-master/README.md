# _Kristi Hwang's Portfolio_

####_Created by: **Kristi Hwang**_

## Description
_This is a landing page made for Kristi Hwang's portfolio.  It will house all major projects and some future projects.  It is a webpage to get to know the developer and her background.  If you'd like to get in touch, you can also follow her on her social media pages.  Some additional information including hobbies and misc. skills are also included.  

## Program setup
* Locate user 'developitkris' and find github repository 'Wk1-Project'  
* Review the files for the repository
* Go into the README.md file for a brief introduction
* Click on the gh-pages link and it should direct you to the published site to view the work
* Load and enjoy!

## Bugs
_There were no known bugs up to the time of this update, as of 16 MARCH 2018_

## Support and Contact
_If you experience any inconvenience with the site, please let me know so I can resolve it.  I would also appreciate any feedback for improvements and advice I can incorporate into my project.  Feel free to contact me at (mailto:krsy3ii@yahoo.com) anytime for additional questions or queries._

## Languages
_HTML_
_CSS_

## Licensing
[link to site on GitHub pages] ("")
**_All rights belonging to KH_**
